# Block9_Personal_Website

Website is separated into 3 html files which all follow one css file and one json file. There is one image file used in all html files. 
